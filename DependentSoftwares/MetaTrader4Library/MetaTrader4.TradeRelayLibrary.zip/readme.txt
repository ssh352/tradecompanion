=======================================================

	MetaTrader 4 TradeRelayLibrary Readme       

=======================================================

1. Description
2. Installing the library
3. Using the Library
4. Known Limitations



1. Description
---------------

This Library creates files for use with TradeCompanion.
It process all open and close orders made after the 
advisor, which uses this library, is added to a chart.
Any previous orders are bypassed, to avoid creating 
any duplicate orders.



2. Installing the Library
--------------------------

To install the library, put the "TradeRelayLibrary.ex4"
file in the libraries folder of your MetaTrader 4 
installation. By default, this folder is:
C:\Program Files\MetaTrader 4\experts\libraries



3. Using the Library
---------------------

To use the library, you must add 2 function calls in your
expert advisor script, for processing open orders, and 
2 function calls for processing close orders. 
You can use either (open/close) or both.

For processing open orders, call TradeRelayCheckOpenOrders()
at the beginning of the init() function and at the end of 
the start() function of the advisor you want to use the 
library with.

For processing close orders, call TradeRelayCheckClosedOrders()
at the beginning of the init() function and at the end of the
start() function of the advisor you want to use the 
library with.


Code Example:

//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
	// TradeRelayLibrary functions calls
   	TradeRelayCheckOpenOrders();
   	TradeRelayCheckClosedOrders();
   	
   	// your advisor init() code here
//----
   return(0);
  }	

//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   	// your advisor start() code here
   	
   	// TradeRelayLibrary functions calls
   	TradeRelayCheckOpenOrders();
   	TradeRelayCheckClosedOrders();
//----
   return(0);
  }



4. Known Limitations
---------------------

To process all close orders, MetaTrader 4 must be running
24/24. If the program is closed at the end of a day and 
open positions are closed while the program is not running,
these orders won't be processed by the Library. This
ensures historical orders do not generate .req files for
older orders and avoid duplicate orders.


=======================================================
Readme Updated: 07-11-2007
=======================================================
